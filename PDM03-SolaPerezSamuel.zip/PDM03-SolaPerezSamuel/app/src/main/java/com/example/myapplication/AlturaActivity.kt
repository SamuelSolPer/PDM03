package com.example.myapplication

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.SeekBar
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class AlturaActivity : AppCompatActivity() {
    var alturaSeekBar: SeekBar? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_altura)
        alturaSeekBar = findViewById<View>(R.id.alturaSeekBar) as SeekBar
        var medidaText = findViewById<View>(R.id.medidaText) as TextView

        alturaSeekBar!!.setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    var altura = progress.toDouble()/100*70+150
                    medidaText.text = ""+altura.toInt()+"cm"
                }

                override fun onStartTrackingTouch(seekBar: SeekBar?) {

                }

                override fun onStopTrackingTouch(seekBar: SeekBar?) {

                }

            })
    }

    fun aceptarBoton(view: View?) {
        val data = Intent(this, MainActivity::class.java)
        var altura = (alturaSeekBar?.progress?: 0)
        altura = (altura.toDouble()/100*70+150).toInt()
        val extras = Bundle()
        extras.putString("ALTURA", ""+altura)
        data.putExtras(extras)

        setResult(RESULT_OK, data)
        finish()
    }

    fun cancelarBoton(v: View?) {
        finish()
    }
}