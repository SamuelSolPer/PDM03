package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class VerActivity extends AppCompatActivity {

    TextView nombreTextView;
    TextView correoTextView;
    TextView fechaTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver);
        nombreTextView = (TextView) findViewById(R.id.nombreTextView);
        correoTextView = (TextView) findViewById(R.id.emailTextView);
        fechaTextView = (TextView) findViewById(R.id.fechaTextView);

        nombreTextView.setText(getIntent().getStringExtra("NOMBRE"));
        correoTextView.setText(getIntent().getStringExtra("EMAIL"));
        fechaTextView.setText(getIntent().getStringExtra("FECHA"));




    }
    public void cancelarBoton(View v) {
        finish();
    }
}