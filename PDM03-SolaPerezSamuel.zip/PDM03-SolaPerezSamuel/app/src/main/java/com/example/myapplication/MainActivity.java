package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Date;

public class MainActivity extends AppCompatActivity {

    int pulsaciones = 0;
    String correo ="";
    String fecha = "";
    String nombre ="";
    String genero = "";
    String altura = "";
    String fecha2 = "";
    String rating = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if ((resultCode == RESULT_OK)) {
            switch(requestCode) {
                case 11: {
                    correo = data.getExtras().getString("EMAIL");
                    fecha = data.getExtras().getString("FECHA");
                    nombre = data.getExtras().getString("NOMBRE");
                }
                case 12: {
                    genero = data.getExtras().getString("GENERO");
                }
                case 13: {
                    altura = data.getExtras().getString("ALTURA");
                }
                case 14: {
                    fecha2 = data.getExtras().getString("FECHA2");
                }
                case 15: {
                    rating = data.getExtras().getString("RATING");
                }
                default: {

                }
            }
        }
    }

    public void altasBoton(View v) {
        Intent intent = new Intent(MainActivity.this, AltaActivity.class);

        startActivityForResult(intent, 11);
    }

    public void verBoton(View v) {
        Intent intent = new Intent(MainActivity.this, VerActivity.class);

        intent.putExtra("EMAIL", correo);
        intent.putExtra("FECHA", fecha);
        intent.putExtra("NOMBRE", nombre);
        intent.putExtra("GENERO", genero);
        intent.putExtra("ALTURA", altura);
        intent.putExtra("FECHA2", fecha2);
        intent.putExtra("RATING", rating);
        startActivity(intent);
    }

    public void valoracionBoton(View v){
        Intent intent = new Intent(MainActivity.this, RatingActivity.class);

        startActivityForResult(intent, 15);
    }

    public void alturaBoton(View v){
        Intent intent = new Intent(MainActivity.this, AlturaActivity.class);

        startActivityForResult(intent, 13);
    }

    public void salirBoton(View v) {
        finish();
        System.exit(0);
    }

    public void generoBoton(View view) {
        Intent intent = new Intent(MainActivity.this, RadioActivity.class);

        startActivityForResult(intent, 12);
    }
    public void fecha2Boton(View view) {
        Intent intent = new Intent(MainActivity.this, CalendarActivity.class);

        startActivityForResult(intent, 14);
    }
}