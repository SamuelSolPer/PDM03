package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Date;

public class MainActivity extends AppCompatActivity {

    int pulsaciones = 0;
    String correo ="";
    String fecha = null;
    String nombre ="";
    Button boton_pulsame;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if ((resultCode == RESULT_OK) && (requestCode == 11)) {
            correo = data.getExtras().getString("EMAIL");
            fecha = data.getExtras().getString("FECHA");
            nombre = data.getExtras().getString("NOMBRE");
        }
    }

    public void altasBoton(View v) {
        Intent intent = new Intent(MainActivity.this, AltaActivity.class);

        startActivityForResult(intent, 11);
    }

    public void verBoton(View v) {
        Intent intent = new Intent(MainActivity.this, VerActivity.class);

        intent.putExtra("EMAIL", correo);
        intent.putExtra("FECHA", fecha);
        intent.putExtra("NOMBRE", nombre);
        startActivity(intent);
    }

    public void valoracionBoton(View v){
        Intent intent = new Intent(MainActivity.this, RatingActivity.class);

        startActivityForResult(intent, 12);
    }

    public void salirBoton(View v) {
        finish();
    }
}