package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class RadioActivity extends AppCompatActivity {
    private RadioGroup radioGroup;
    private RadioButton radioButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_radio);
        radioGroup = (RadioGroup) findViewById(R.id.radioGroup);
    }

    public void aceptarBoton(View view) {
        try {
            Intent data = new Intent(this, MainActivity.class);
            Bundle extras = new Bundle();
            int selectedId = radioGroup.getCheckedRadioButtonId();

            // find the radiobutton by returned id
            radioButton = (RadioButton) findViewById(selectedId);
            extras.putString("GENERO", (String) radioButton.getText());
            data.putExtras(extras);
            setResult(RESULT_OK, data);
            Log.i("SUCCESS","Se ha obtenido el genero correctamente");
        }catch(Exception e){
            Log.e("NODATA","Error: no se han insertado datos");
        }
        finish();
    }
    public void cancelarBoton(View v) {
        finish();
    }
}